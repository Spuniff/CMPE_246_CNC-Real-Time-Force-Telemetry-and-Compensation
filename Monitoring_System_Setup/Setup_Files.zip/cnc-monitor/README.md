# CNC Force Monitor

Real-time CNC force monitoring dashboard. ESP32 + HX711 strain gauge → Raspberry Pi → live web dashboard with email alerts.

---

## Setup on the Pi

### 1. Install Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
```

### 2. Clone and install
```bash
git clone <your-repo-url> cnc-monitor
cd cnc-monitor
npm install
```

### 3. Configure credentials
```bash
cp .env.example .env
nano .env
```
Fill in your serial port and Gmail app password.

**Find your serial port:**
```bash
ls /dev/tty*    # unplug ESP32, run, plug back in, run again — new entry is it
```

### 4. Run
```bash
npm start
```

Open `http://localhost:3000` — you should see the dashboard with live data.

---

## Make it public (share with anyone)

### Option A — ngrok (easiest, instant)
```bash
# Install ngrok
curl -s https://ngrok-agent.s3.amazonaws.com/ngrok.asc | sudo tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null
echo "deb https://ngrok-agent.s3.amazonaws.com buster main" | sudo tee /etc/apt/sources.list.d/ngrok.list
sudo apt update && sudo apt install ngrok

# Authenticate (free at ngrok.com)
ngrok config add-authtoken <your-token>

# Expose the server
ngrok http 3000
```
You get a public URL like `https://abc123.ngrok.io` — share that link.

### Option B — Tailscale (permanent, more reliable)
```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
```
Your Pi gets a permanent `https://pi.tail12345.ts.net` URL accessible to anyone you invite to your Tailscale network.

### Option C — Port forwarding
Forward port 3000 on your router to the Pi's local IP. Your public URL is `http://<your-public-ip>:3000`.

---

## Run on startup (Pi)

```bash
# Install pm2
sudo npm install -g pm2

# Start and save
pm2 start server.js --name cnc-monitor
pm2 save
pm2 startup   # follow the printed command
```

Now it auto-starts after every reboot.

---

## Email setup (Gmail)

1. Google account → Security → 2-Step Verification → enable
2. Search "App passwords" → create one → copy the 16-char password
3. Paste into `.env` as `EMAIL_PASS`
4. Restart the server

---

## Fill in the team bios

Open `public/index.html`, find the `<!-- ── TEAM ── -->` section and edit the three `.team-card` blocks with your real names, roles, and bios.

---

## Wiring reminder

```
HX711    →    ESP32
VCC      →    3.3V
GND      →    GND
DT       →    GPIO 18
SCK      →    GPIO 19
```

The Arduino firmware (`torque_sensor.cpp`) runs on the ESP32 unchanged — this server just reads its serial output.
