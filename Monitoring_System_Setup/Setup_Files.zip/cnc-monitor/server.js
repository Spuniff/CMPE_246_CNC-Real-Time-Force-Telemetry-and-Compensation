require('dotenv').config();
const express    = require('express');
const http       = require('http');
const WebSocket  = require('ws');
const nodemailer = require('nodemailer');
const fs         = require('fs');
const path       = require('path');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Config ──────────────────────────────────────────────────
const PORT        = process.env.PORT        || 3000;
const SERIAL_PORT = process.env.SERIAL_PORT || '/dev/ttyUSB0';
const SERIAL_BAUD = parseInt(process.env.SERIAL_BAUD) || 115200;

// ── Email ────────────────────────────────────────────────────
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

// ── Subscribers ──────────────────────────────────────────────
const SUB_FILE  = path.join(__dirname, 'subscribers.json');
let subscribers = fs.existsSync(SUB_FILE)
  ? JSON.parse(fs.readFileSync(SUB_FILE, 'utf8'))
  : [];

const saveSubs = () =>
  fs.writeFileSync(SUB_FILE, JSON.stringify(subscribers, null, 2));

// ── Alert state ──────────────────────────────────────────────
let alertThreshold  = parseFloat(process.env.DEFAULT_THRESHOLD) || 50.0;
let lastAlertTime   = 0;
const COOLDOWN_MS   = 5 * 60 * 1000;

// ── Stats ────────────────────────────────────────────────────
const stats = {
  samples:    0,
  startTime:  Date.now(),
  maxForce:   -Infinity,
  minForce:    Infinity,
  estopCount: 0,
  lastEstop:  null,
};

// ── Broadcast helper ─────────────────────────────────────────
function broadcast(obj) {
  const msg = JSON.stringify(obj);
  wss.clients.forEach(c => {
    if (c.readyState === WebSocket.OPEN) c.send(msg);
  });
}

// ── Parse one serial line ─────────────────────────────────────
function parseLine(line) {
  if (line.includes('E-STOP')) {
    stats.estopCount++;
    stats.lastEstop = new Date().toISOString();
    broadcast({ type: 'estop', time: stats.lastEstop });
    return;
  }

  const out = {};
  line.split(',').forEach(part => {
    const idx = part.indexOf(':');
    if (idx === -1) return;
    const key = part.slice(0, idx).trim();
    const val = parseFloat(part.slice(idx + 1));
    if (!isNaN(val)) out[key] = val;
  });

  const force     = out['Force(N)']      ?? null;
  const delta     = out['RawDelta(N)']   ?? null;
  const drift     = out['DriftRate(N)']  ?? null;
  const corrected = out['CorrectedDelta'] ?? null;

  if (force === null) return;

  stats.samples++;
  if (force > stats.maxForce) stats.maxForce = force;
  if (force < stats.minForce) stats.minForce = force;

  const payload = {
    type:      'data',
    ts:        Date.now(),
    force,
    delta,
    drift,
    corrected,
    threshold: alertThreshold,
    stats: {
      samples:      stats.samples,
      uptime:       Math.floor((Date.now() - stats.startTime) / 1000),
      maxForce:     stats.maxForce === -Infinity ? 0 : +stats.maxForce.toFixed(4),
      minForce:     stats.minForce ===  Infinity ? 0 : +stats.minForce.toFixed(4),
      estopCount:   stats.estopCount,
      lastEstop:    stats.lastEstop,
    },
  };

  broadcast(payload);

  // Email alert
  const now = Date.now();
  if (
    corrected !== null &&
    Math.abs(corrected) > alertThreshold &&
    (now - lastAlertTime) > COOLDOWN_MS
  ) {
    lastAlertTime = now;
    sendAlerts(force, corrected);
  }
}

// ── Serial (with demo fallback) ───────────────────────────────
try {
  const { SerialPort }      = require('serialport');
  const { ReadlineParser }  = require('@serialport/parser-readline');
  const port   = new SerialPort({ path: SERIAL_PORT, baudRate: SERIAL_BAUD });
  const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));
  parser.on('data', line => parseLine(line.trim()));
  console.log(`Serial: ${SERIAL_PORT} @ ${SERIAL_BAUD}`);
} catch (err) {
  console.warn(`Serial unavailable (${err.message}) — running DEMO mode`);
  let t = 0;
  setInterval(() => {
    t += 0.05;
    const force     = Math.sin(t * 0.4) * 12 + Math.sin(t * 1.1) * 3 + (Math.random() - 0.5) * 1.5;
    const delta     = Math.cos(t * 0.9) * 4  + (Math.random() - 0.5) * 0.8;
    const drift     = Math.sin(t * 0.02) * 0.6;
    const corrected = delta - drift;
    parseLine(
      `Force(N):${force.toFixed(3)},RawDelta(N):${delta.toFixed(3)},DriftRate(N):${drift.toFixed(4)},CorrectedDelta:${corrected.toFixed(3)}`
    );
  }, 80);
}

// ── Email ─────────────────────────────────────────────────────
async function sendAlerts(force, corrected) {
  if (!subscribers.length || !process.env.EMAIL_USER) return;
  const subject = `⚠ CNC Force Alert — Threshold Exceeded`;
  const html = `
  <div style="font-family:monospace;background:#0d0d14;color:#e2e8f0;padding:32px;border-radius:12px;max-width:520px;">
    <div style="font-size:22px;font-weight:700;color:#f59e0b;margin-bottom:8px;">⚠ CNC Force Monitor</div>
    <div style="color:#94a3b8;margin-bottom:24px;">Threshold exceeded at ${new Date().toLocaleString()}</div>
    <table style="width:100%;border-collapse:collapse;">
      <tr style="border-bottom:1px solid #1e293b;">
        <td style="padding:10px 0;color:#94a3b8;">Force (N)</td>
        <td style="padding:10px 0;color:#f59e0b;font-size:1.3em;font-weight:700;">${force.toFixed(3)}</td>
      </tr>
      <tr style="border-bottom:1px solid #1e293b;">
        <td style="padding:10px 0;color:#94a3b8;">Corrected Delta (N)</td>
        <td style="padding:10px 0;color:#ef4444;font-size:1.3em;font-weight:700;">${corrected.toFixed(3)}</td>
      </tr>
      <tr>
        <td style="padding:10px 0;color:#94a3b8;">Your Threshold</td>
        <td style="padding:10px 0;">${alertThreshold.toFixed(2)} N</td>
      </tr>
    </table>
    <div style="margin-top:28px;padding:16px;background:#1e293b;border-radius:8px;font-size:0.85em;color:#64748b;">
      You're subscribed to alerts from CNC Force Monitor.<br>
      To unsubscribe, visit the dashboard and remove your email.
    </div>
  </div>`;

  for (const email of subscribers) {
    try {
      await transporter.sendMail({ from: process.env.EMAIL_USER, to: email, subject, html });
      console.log(`Alert → ${email}`);
    } catch (e) {
      console.error(`Email failed → ${email}: ${e.message}`);
    }
  }
}

// ── REST API ──────────────────────────────────────────────────
app.get('/api/threshold', (req, res) => res.json({ threshold: alertThreshold }));

app.post('/api/threshold', (req, res) => {
  const v = parseFloat(req.body.threshold);
  if (isNaN(v) || v <= 0) return res.status(400).json({ error: 'Invalid value' });
  alertThreshold = v;
  broadcast({ type: 'threshold', threshold: alertThreshold });
  res.json({ threshold: alertThreshold });
});

app.get('/api/subscribers', (req, res) =>
  res.json({ count: subscribers.length })
);

app.post('/api/subscribe', (req, res) => {
  const { email } = req.body;
  if (!email || !email.includes('@')) return res.status(400).json({ error: 'Invalid email' });
  if (!subscribers.includes(email)) {
    subscribers.push(email);
    saveSubs();
  }
  res.json({ ok: true, message: 'Subscribed!' });
});

app.post('/api/unsubscribe', (req, res) => {
  const { email } = req.body;
  subscribers = subscribers.filter(s => s !== email);
  saveSubs();
  res.json({ ok: true });
});

// ── WebSocket: send current threshold on connect ──────────────
wss.on('connection', ws => {
  ws.send(JSON.stringify({ type: 'init', threshold: alertThreshold }));
});

// ── Start ─────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\nCNC Force Monitor → http://localhost:${PORT}\n`);
});
